- Correr jar com
    java -jar blokus.jar
